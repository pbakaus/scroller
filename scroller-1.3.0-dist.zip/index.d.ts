/*
 * Scroller
 * http://github.com/zynga/scroller
 *
 * Copyright 2011, Zynga Inc.
 * Licensed under the MIT License.
 * https://raw.github.com/zynga/scroller/master/MIT-LICENSE.txt
 */

export interface ScrollerOptions {
	/** Enable scrolling on x-axis */
	scrollingX?: boolean;
	/** Enable scrolling on y-axis */
	scrollingY?: boolean;
	/** Enable animations for deceleration, snap back, zooming and scrolling */
	animating?: boolean;
	/** duration for animations triggered by scrollTo/zoomTo */
	animationDuration?: number;
	/** Enable bouncing (content can be slowly moved outside and jumps back after releasing) */
	bouncing?: boolean;
	/** Enable locking to the main axis if user moves only slightly on one of them at start */
	locking?: boolean;
	/** Enable pagination mode (switching between full page content panes) */
	paging?: boolean;
	/** Enable snapping of content to a configured pixel grid */
	snapping?: boolean;
	/** Enable zooming */
	zooming?: boolean;
	/** Minimum zoom level */
	minZoom?: number;
	/** Maximum zoom level */
	maxZoom?: number;
	/** Callback for scroll completion */
	scrollingComplete?: () => void;
	/** Callback for zoom completion */
	zoomingComplete?: () => void;
	/** Callback for penetration out of boundaries */
	penetrationDeceleration?: number;
	/** Callback for penetration acceleration */
	penetrationAcceleration?: number;
}

export interface ScrollerValues {
	left: number;
	top: number;
	zoom: number;
}

export interface Touch {
	pageX: number;
	pageY: number;
}

export type ScrollerCallback = (left: number, top: number, zoom: number) => void;

export declare class Scroller {
	constructor(callback: ScrollerCallback, options?: ScrollerOptions);
	
	options: ScrollerOptions;
	
	/** Setup scroll object dimensions */
	setDimensions(clientWidth: number, clientHeight: number, contentWidth: number, contentHeight: number): void;
	
	/** Setup scroll object position (in relation to the document) */
	setPosition(clientLeft: number, clientTop: number): void;
	
	/** Setup snap dimensions */
	setSnapSize(width: number, height: number): void;
	
	/** Setup pull-to-refresh */
	activatePullToRefresh(height: number, activate: () => void, deactivate: () => void, start: () => void): void;
	
	/** Stop pull-to-refresh session */
	finishPullToRefresh(): void;
	
	/** Get current scroll positions and zooming */
	getValues(): ScrollerValues;
	
	/** Zoom to a specific level */
	zoomTo(level: number, animate?: boolean, originLeft?: number, originTop?: number): void;
	
	/** Zoom by a given amount */
	zoomBy(factor: number, animate?: boolean, originLeft?: number, originTop?: number): void;
	
	/** Scroll to a specific position */
	scrollTo(left: number, top: number, animate?: boolean): void;
	
	/** Scroll by the given amount */
	scrollBy(leftOffset: number, topOffset: number, animate?: boolean): void;
	
	/** Handle mouse wheel zoom */
	doMouseZoom(wheelDelta: number, timeStamp: number, pageX: number, pageY: number): void;
	
	/** Handle touch start */
	doTouchStart(touches: Touch[], timeStamp: number): void;
	
	/** Handle touch move */
	doTouchMove(touches: Touch[], timeStamp: number, scale?: number): void;
	
	/** Handle touch end */
	doTouchEnd(timeStamp: number): void;
}

export interface AnimateOptions {
	/** Animation duration in milliseconds */
	duration?: number;
	/** Easing function */
	easing?: (percent: number) => number;
}

export declare class Animate {
	/** Request animation frame polyfill */
	static requestAnimationFrame(callback: (time: number) => void, root?: Element): number;
	
	/** Stop animation by ID */
	static stop(id: number): boolean;
	
	/** Check if animation is running */
	static isRunning(id: number): boolean;
	
	/** Start animation */
	static start(
		stepCallback: (percent: number, now: number, virtual: boolean) => boolean | void,
		verifyCallback?: () => boolean,
		completedCallback?: (droppedFrames: number, finishedAnimation: boolean) => void,
		duration?: number,
		easingMethod?: (percent: number) => number,
		root?: Element
	): number;
}

export declare class EasyScroller {
	constructor(content: Element, options?: ScrollerOptions);
	
	content: Element;
	container: Element;
	scroller: Scroller;
	
	/** Render method */
	render(left: number, top: number, zoom: number): void;
	
	/** Reflow method */
	reflow(): void;
	
	/** Get scroller values */
	getValues(): ScrollerValues;
	
	/** Zoom to level */
	zoomTo(level: number, animate?: boolean): void;
	
	/** Zoom by factor */
	zoomBy(factor: number, animate?: boolean): void;
	
	/** Scroll to position */
	scrollTo(left: number, top: number, animate?: boolean): void;
	
	/** Scroll by offset */
	scrollBy(leftOffset: number, topOffset: number, animate?: boolean): void;
}

export default Scroller; 